# CAJADM Oficial 2026 — projeto novo

Site HTML/CSS/JavaScript puro, com nove páginas e imagens locais. Abra `inicio.html` no navegador para ver a versão independente do WordPress.

## Instalar no WordPress

1. Desative o plugin antigo **CAJADM 2026 Site** em Plugins. Não exclua as páginas do WordPress.
2. Instale `cajadm-oficial-wordpress.zip` em **Plugins → Adicionar plugin → Enviar plugin** e ative **CAJADM Oficial 2026**.
3. As páginas já criadas continuam com os mesmos slugs (`inicio`, `sobre`, `programacao`, `convidados`, `inscricoes`, `documentos`, `resultados`, `organizacao`, `floriano`) e o shortcode `[cajadm pagina="slug"]`.
4. Em **Configurações → Leitura**, mantenha a página `inicio` como página inicial. Em **Links permanentes**, use **Nome do post**.
5. Verifique o endereço público em uma aba anônima. O tema Astra continua ativo para o painel e outras páginas, mas não é carregado nas nove páginas do evento.

O site é editado nos arquivos HTML, CSS e JS do plugin. Para mudar conteúdo, altere os arquivos correspondentes e envie novamente o ZIP. Fotos ficam em `assets`. A versão independente está em `cajadm-oficial-site.zip`.

## Verificação

Um único cabeçalho, menu e rodapé em cada página. Menu mobile abre e fecha com o mesmo botão; links navegam diretamente. A programação tem abas acessíveis; a galeria de Floriano abre e fecha imagens. Teste também em seu celular após instalar, pois o ambiente de desenvolvimento não executa o WordPress da hospedagem.
