(() => {
  'use strict';
  const button = document.querySelector('.menu-button');
  const menu = document.querySelector('.mobile-nav');
  function setOpen(open) {
    if (!button || !menu) return;
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
    menu.classList.toggle('open', open);
    menu.inert = !open;
  }
  button?.addEventListener('click', () => setOpen(button.getAttribute('aria-expanded') !== 'true'));
  menu?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setOpen(false)));
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && button?.getAttribute('aria-expanded') === 'true') { setOpen(false); button.focus(); } });
  window.addEventListener('resize', () => { if (window.innerWidth > 900) setOpen(false); });
  const top = document.querySelector('.to-top');
  window.addEventListener('scroll', () => top?.classList.toggle('visible', scrollY > 480), {passive:true});
  top?.addEventListener('click', () => window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'}));
  const tabs = [...document.querySelectorAll('[role="tab"]')];
  function activate(tab, focus=false) {
    tabs.forEach(item => { const active=item===tab; item.setAttribute('aria-selected', String(active)); item.tabIndex=active?0:-1; const panel=document.getElementById(item.getAttribute('aria-controls')); if(panel)panel.hidden=!active; });
    if (focus) tab.focus();
  }
  tabs.forEach((tab,index) => {
    tab.addEventListener('click', () => activate(tab));
    tab.addEventListener('keydown', event => { let next;if(event.key==='ArrowRight')next=(index+1)%tabs.length;else if(event.key==='ArrowLeft')next=(index-1+tabs.length)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;event.preventDefault();activate(tabs[next],true); });
  });
  const dialog=document.querySelector('.lightbox');
  document.querySelectorAll('[data-image]').forEach(button => button.addEventListener('click', () => {if(!dialog)return; const image=dialog.querySelector('img');image.src=button.dataset.image;image.alt=button.querySelector('img')?.alt||'';dialog.querySelector('p').textContent=button.dataset.caption||'';dialog.showModal();}));
  dialog?.querySelector('.lightbox-close')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', event => {if(event.target===dialog)dialog.close();});
})();
