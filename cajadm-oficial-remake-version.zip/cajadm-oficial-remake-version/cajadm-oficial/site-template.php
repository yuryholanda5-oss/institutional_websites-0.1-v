<?php
if (!defined('ABSPATH')) { exit; }
$pages = cajadm_oficial_paginas();
$slug = isset($GLOBALS['cajadm_oficial_slug']) ? $GLOBALS['cajadm_oficial_slug'] : '';
if (!isset($pages[$slug])) { status_header(404); exit; }
$path = plugin_dir_path(__FILE__) . $pages[$slug];
if (!is_readable($path)) { status_header(500); exit; }
$html = file_get_contents($path);
$base = plugin_dir_url(__FILE__);
$html = str_replace('href="style.css"', 'href="' . esc_url($base . 'style.css?ver=1.0.0') . '"', $html);
$html = str_replace('src="script.js"', 'src="' . esc_url($base . 'script.js?ver=1.0.0') . '"', $html);
$html = str_replace('assets/', esc_url($base . 'assets/'), $html);
foreach ($pages as $page_slug => $filename) {
    $html = str_replace('href="' . $filename . '"', 'href="' . esc_url(home_url('/' . $page_slug . '/')) . '"', $html);
}
$canonical = $slug === 'inicio' ? home_url('/') : home_url('/' . $slug . '/');
$html = str_replace('</head>', '<link rel="canonical" href="' . esc_url($canonical) . '"></head>', $html);
header('Content-Type: text/html; charset=UTF-8');
echo $html;
