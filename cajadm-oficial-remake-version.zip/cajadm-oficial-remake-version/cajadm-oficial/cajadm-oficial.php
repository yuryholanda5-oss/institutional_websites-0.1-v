<?php
/**
 * Plugin Name: CAJADM Oficial 2026
 * Description: Site completo do CAJADM com navegação própria para as páginas do evento.
 * Version: 1.0.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }

function cajadm_oficial_paginas() {
    return array(
        'inicio'=>'inicio.html','sobre'=>'sobre.html','programacao'=>'programacao.html',
        'convidados'=>'convidados.html','inscricoes'=>'inscricoes.html','documentos'=>'documentos.html',
        'resultados'=>'resultados.html','organizacao'=>'organizacao.html','floriano'=>'floriano.html'
    );
}

function cajadm_oficial_template($template) {
    if (!is_page()) { return $template; }
    $post = get_queried_object();
    if (!$post || !has_shortcode($post->post_content, 'cajadm')) { return $template; }
    $pages = cajadm_oficial_paginas();
    $slug = sanitize_key($post->post_name);
    if (!isset($pages[$slug])) { return $template; }
    $GLOBALS['cajadm_oficial_slug'] = $slug;
    return plugin_dir_path(__FILE__) . 'site-template.php';
}
add_filter('template_include', 'cajadm_oficial_template', 999);

function cajadm_oficial_shortcode($atts) {
    return '<p>Abra esta página publicada para visualizar o CAJADM.</p>';
}
add_shortcode('cajadm', 'cajadm_oficial_shortcode');
